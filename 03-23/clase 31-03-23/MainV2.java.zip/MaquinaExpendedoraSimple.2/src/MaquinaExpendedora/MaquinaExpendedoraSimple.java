package MaquinaExpendedora;
import java.time.LocalDateTime;
import java.util.Scanner;

public class MaquinaExpendedoraSimple {
    public static Scanner escaner = new Scanner ( System.in );
    public Boleto[] boletos;
    public Cliente[] clientes;
    public int saldo;
    public int recaudacion;
    public int precioActual;
    public int cantidadBoletos;
    public int topeBoletos;
    public int cantidadClientes;
    public int topeClientes;
    public final LocalDateTime fecha;

    public MaquinaExpendedoraSimple(int topeBoletos, int topeClientes,
                                    int precioActual, int saldo) {
        this.boletos = new Boleto[topeBoletos];
        this.clientes = new Cliente[topeClientes];
        this.topeBoletos = topeBoletos;
        this.topeClientes = topeClientes;
        this.recaudacion = 0;
        this.precioActual = precioActual;
        this.saldo = saldo;
        this.cantidadBoletos = 0;
        this.cantidadClientes = 0;
        this.fecha = LocalDateTime.now ();
    }

    /// - - - Getters
    public int getRecaudacion() {
        return this.recaudacion;
    }
    public int getprecioActual() {
        return this.precioActual;
    }
    public int getSaldo() {
        return this.saldo;
    }
    public int getCantidadBoletos() {return this.cantidadBoletos;}
    public LocalDateTime getFecha(){return this.fecha;}
    public int getPrecioActual() {return this.precioActual;}
    public int getTopeBoletos() {return this.topeBoletos;}

    /// - - - Setters
    public void setTopeBoletos(int topeBoletos) {
        this.topeBoletos = topeBoletos;
    }
    public void setPrecioActual(int precioActual) {
        this.precioActual = precioActual;
    }
    public void setTopeClientes(int topeClientes) {
        this.topeClientes = topeClientes;
    }

    /// - - - Metodos
    public Boleto imprimirBoleto(int precioActual, LocalDateTime fecha, String nombreCliente, String dniCliente, String tipoCliente)
    {
        //METODO QUE LLAMA AL CONSTRUCTOR DE LA CLASE 'BOLETO' PARA CREAR UNA INSTANCIA Y RETORNARLA.
        Boleto boleto = new Boleto (precioActual, fecha, nombreCliente, dniCliente, tipoCliente);
        return boleto;
    }
    public void registrarBoleto(Boleto boleto) {
        boletos[this.cantidadBoletos] = boleto;
        this.topeBoletos--;
        this.cantidadBoletos ++;
        this.saldo = this.saldo - boleto.getPrecioEmitido ();
        this.recaudacion = this.recaudacion + boleto.getPrecioEmitido ();
    }
    public Boleto[] getBoletos() {
        return boletos;
    }
    public void informacionBoleto(Boleto boleto) {
        System.out.println ("precio - $" + boleto.getPrecioEmitido () + " pesos.");
        System.out.println (boleto.getFechaConvertida ());
    }
    public void verBoletos() {
        for (int i = 0; i < cantidadBoletos; i++) {
            informacionBoleto ( boletos[i] );
        }
    }
    public void informacionCliente(Cliente cliente) {
        System.out.println ("Nombre: " + cliente.getNombre ());
        System.out.println ("DNI: " + cliente.getDni ());
        System.out.println (cliente.getTipoCliente ());
    }
    public void verClientes() {
        for (int i = 0; i < this.cantidadClientes; i++) {
            informacionCliente ( this.clientes[i] );
        }
    }
}
