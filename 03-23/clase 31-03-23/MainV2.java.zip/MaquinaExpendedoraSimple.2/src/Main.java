/* "IMPORTANTE"
En esta version el menu completo se encuentra dentro del main.
Esta decisión fue tomada porque creo haber escuchado decir que el metodo scanner tiene que estar si o sí en la clase 'main'
Por lo que voy a tener que enviar la mayoria de las funciones al main e ingresar como parametro a la maquinaexpendedora.
* */
import MaquinaExpendedora.MaquinaExpendedoraSimple;
import MaquinaExpendedora.Boleto;
import MaquinaExpendedora.Cliente;
import java.util.Scanner;
public class Main {
    public static Scanner escaner = new Scanner ( System.in );
    public static MaquinaExpendedoraSimple maquina = new MaquinaExpendedoraSimple (100, 100, 100, 1000);
    //metodos
    public static void imprimirMenuIngreso() {
        //METODO QUE MUESTRA LAS OPCIONES AL INICIO DEL SISTEMA
        System.out.println ("           Bienvenido!");
        System.out.println ("Ingresar");
        System.out.println ("1) Si es cliente");
        System.out.println ("2) Si es operario de estación");
    }
    public static String imprimirMenuUsuario() {
        //METODO QUE MUESTRA LAS OPCIONES DEL MENU DEL USUARIOs
        String eleccion;
        System.out.println ("1) para comprar un boleto");
        System.out.println ("0 para cerrar la sesion");
        eleccion = escaner.nextLine (); //opcion elegida
        return eleccion;
    }
    public static String imprimirMenuTecnico() {
        //METODO QUE MUESTRA LAS OPCIONES DEL MENU DEL TECNICO
        String eleccion;
        System.out.println ("1) para ver la recaudacion");
        System.out.println ("2) para ver el saldo actual");
        System.out.println ("3) para ver el precio actual");
        System.out.println ("4) para ver la cantidad de boletos impresos");
        System.out.println ("5) para ver informacion de los boletos impresos");
        System.out.println ("6) para juntar lo recaudado por la maquina");
        System.out.println ("7) para ver informacion de los clientes que han comprado");
        System.out.println ("8) para modificar el precio del boleto");
        System.out.println ("9) para modificar el tope de boletos");
        System.out.println ("0 para cerrar la sesion");
        eleccion = escaner.nextLine (); //opcion elegida
        return eleccion;
    }
    public static char imprimirMenuSalida() {
        String sesionActual;
        char sesionActualChar;
        System.out.println ("1) para iniciar una nueva sesion");
        System.out.println ("0) para salir del sistema");
        sesionActual = escaner.nextLine ();
        sesionActualChar = sesionActual.charAt ( 0 );
        return sesionActualChar;
    }
    public static String devolvertipoUsuario(char entrada)
    {
        //FUNCION QUE RETORNA EN UNA VARIABLE DE TIPO STRING SI EL USUARIO ES CLIENTE O TECNICO
        String retorno = "";
        if ( entrada == '1' ) {
            retorno = "usuario";
        } else if ( entrada == '2' ) {
            retorno  = "tecnico";
        }
        return retorno;
    }
    public static boolean verificarTopeUsuarios(MaquinaExpendedoraSimple maquina, int cantidadClientes)
    {
        boolean retorno = true;
        if ( cantidadClientes == maquina.topeClientes )
            retorno = false;
        return retorno;
    }
    public static void actualizacionMaquina(MaquinaExpendedoraSimple maquina, Boleto boleto) {
        maquina.boletos[maquina.cantidadBoletos] = boleto;
        maquina.cantidadBoletos++;
        maquina.saldo = maquina.saldo - maquina.precioActual;
        maquina.recaudacion = maquina.recaudacion + maquina.precioActual;
    }

    ///         - - -           MENU PRINCIPAL          - - -           \\\
    public static void menu() {
        String usuario; //
        String identidad; // NOMBRE Y APELLIDO
        String tipoUsuario; // CLIENTE O TECNICO
        String dni; // DNI
        String eleccion; // OPCION ELEGIDA DENTRO DEL MENU DE USUARIO
        char sesionActualChar; // FUTURO 'CHAR.AT(0)'
        char usuarioChar; // FUTURO 'CHAR.AT(0)'
        boolean salir;
        boolean sesion = true;

        while ( sesion ) {

            imprimirMenuIngreso ();

            // INDICACION DEL TIPO DE USUARIO
            usuario = escaner.nextLine ();
            usuarioChar = usuario.charAt ( 0 );

            //INFORMACION DE IDENTIDAD
            System.out.println ( "nombre y apellido: " );
            identidad = escaner.nextLine ();
            System.out.println ( "dni: " );
            dni = escaner.nextLine ();

            // TIPO DE USUARIO EN STRING
            tipoUsuario = devolvertipoUsuario ( usuarioChar );

            // CONSTRUCTOR DEL USUARIO VERIFICANDO CANTIDAD DE CLIENTES INGRESADOS PREVIAMENTE AL SISTEMA
            if ( verificarTopeUsuarios ( maquina, maquina.cantidadClientes ) ) {
                Cliente cliente = new Cliente ( identidad, dni, tipoUsuario );
                maquina.clientes[maquina.cantidadClientes] = cliente;
                maquina.cantidadClientes++; //---  -  -  - /\   -  --  -  MENUS  -  --  -   /\ -  -  -  ---//
                maquina.topeClientes--;
                salir = false;
                while ( !salir ) {
                    // - - - MENU cliente - - - //
                    if ( usuarioChar == '1' ) {
                        eleccion = imprimirMenuUsuario ();
                        switch (eleccion.charAt ( 0 )) {
                            case '0' -> { //SALIDA DEL MENU
                                System.out.println ( "Cerrando sesion..." );
                                salir = true;
                            }
                            case '1' -> { //ES POSIBLE LA COMPRA
                                /*
                                IMPRESION DEL BOLETO, ACTUALIZACION DE LOS DATOS CON RESPECTO A
                                - CANTIDAD DE BOLETOS IMPRESOS
                                - SALDO RESTANTE
                                - RECAUDACION OBTENIDA
                                 (verificando siempre que sea posible realizar la accion...)
                                */
                                if ( (maquina.saldo - maquina.precioActual) >= 0 && (maquina.cantidadBoletos < maquina.topeBoletos) ) {
                                    System.out.println ( "En segundos se habra generado su boleto..." );
                                    Boleto boleto = new Boleto ( maquina.precioActual, maquina.fecha, cliente.getNombre (), cliente.getDni (), cliente.getTipoCliente ());
                                    maquina.registrarBoleto ( boleto );
                                    //actualizacionMaquina ( maquina, boleto ); //ACTUALIZACION DE SALDO, RECAUDACION Y CANTIDAd DE BOLETOS IMPRESOS
                                } else { //NO ES POSIBLE LA COMPRA
                                    if ( maquina.cantidadBoletos == maquina.topeBoletos ) { //TOPE DE BOLETOS GENERADOS
                                        System.out.println ( "La maquina ha alcanzado el tope de generacion de boletos diario" );
                                    } else if ( maquina.saldo < maquina.precioActual ) { //INSUFICIENTE SALDO DE LA TERMINAL
                                        System.out.println ( "La maquina se ha quedado sin saldo. Llame al tecnico encargado" );
                                    }
                                }
                                salir = true;
                            }
                            default -> //OPCION INVALIDA
                                    System.out.println ( "Opción inválida." );
                        }
                    }
                    // - - - MENU TECNICO - - - //
                    else if ( usuarioChar == '2' ) {
                        eleccion = imprimirMenuTecnico (); //OPCION ELEGIDA
                        switch (eleccion.charAt ( 0 )) {
                            case '0' -> { //SALIDA DEL MENU
                                System.out.println ( "Cerrando sesion..." );
                                salir = true;
                            }
                            case '1' -> { //VER RECAUDACION DE LA MAQUINA
                                System.out.println ( "recaudacion: " + maquina.getRecaudacion () );
                            }
                            case '2' -> { //VER SALDO RESTANTE DE LA MAQUINA
                                System.out.println ( "saldo restante: " + maquina.getSaldo () );
                            }
                            case '3' -> { //VER PRECIO ACTUAL DE LA MAQUINA
                                System.out.println ( "precio actual del boleto: " + maquina.getPrecioActual () );
                            }
                            case '4' -> { //VER CANTIDAD DE BOLETOS IMPRESOS
                                System.out.println ( "cantidad de boletos impresos hasta el momento: " + maquina.getCantidadBoletos () );
                            }
                            case '5' -> { //VER INFO DE BOLETOS IMPRESOS
                                maquina.verBoletos (  );
                            }
                            case '6' -> { //JUNTAR LA RECAUDACION
                                System.out.println ( "//La recaudacion ha sido entregada." );
                                maquina.recaudacion = 0;
                            }
                            case '7' -> { //VER INFO DE LOS CLIENTES QUE COMPRARON
                                maquina.verClientes (  );
                            }
                            case '8' -> { //MODIFICAR PRECIO DE COMPRA DEL BOLETO ------------> NO FUNCIONA
                                System.out.println ( "//MODIFICAR EL PRECIO DEL BOLETO" );
                                System.out.println ( "Establecer nuevo precio del boleto: " );
                                int nuevoPrecio = escaner.nextInt ();
                                maquina.setPrecioActual ( nuevoPrecio );
                            }
                            case '9' -> { //MODIFICAR EL TOPE DE BOLETOS ------------> NO FUNCIONA
                                System.out.println ( "//MODIFICAR EL TOPE DE BOLETOS" );
                                System.out.println ( "Establecer nuevo tope de boletos:" );
                                int nuevoTopeBoletos = escaner.nextInt ();
                                maquina.setTopeBoletos (nuevoTopeBoletos);
                            }
                            default -> //OPCION INVALIDA
                                    System.out.println ( "Opcion invalida." );
                        }
                    } else {
                        salir = true;
                    }
                }
            } else {
                System.out.println ( "La cantidad de usuarios ingresados ha alcanzado el tope. Dirigase a otra estacion." );
            }

            sesionActualChar = imprimirMenuSalida ();

            if ( sesionActualChar == '0' ) {
                System.out.println ( "Saliendo del sistema..." );
                sesion = false;
            } else if ( sesionActualChar == '1' ) {
                System.out.println ( "Iniciando nueva sesion..." );
            } else {
                System.out.println ( "Dato invalido >_<" );
                System.out.println ( "Iniciando nueva sesion... :&" );
            }
        }
    }
    public static void main(String[] args)
    {
        Boleto boletos[] = new Boleto[100];
        Cliente clientes[] = new Cliente[100];
        MaquinaExpendedoraSimple maquinola = new MaquinaExpendedoraSimple (500,
                100, 100, 10000);
        menu ();
    }
}