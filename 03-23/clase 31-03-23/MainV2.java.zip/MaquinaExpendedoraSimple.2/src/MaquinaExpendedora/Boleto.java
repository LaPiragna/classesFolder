package MaquinaExpendedora;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Boleto {
    //atributos
    private int precioEmitido;
    private static LocalDateTime fechaEmision;
    private static DateTimeFormatter formateador;
    private String fechaConvertida;
    Cliente cliente;
    //constructor

    public Boleto() {
        this.precioEmitido = 0;
        this.fechaEmision = fechaEmision;
        this.formateador = DateTimeFormatter.ofPattern ( "yyyy MM dd" );
        this.fechaConvertida = fechaEmision.format ( formateador );
    }
    public Boleto(int precioEmitido, LocalDateTime fechaEmision, String nombreCliente, String dniCliente, String tipoCliente) {
        this.precioEmitido = precioEmitido;
        this.fechaEmision = fechaEmision;
        this.formateador = DateTimeFormatter.ofPattern ( "yyyy-MM-dd HH:mm:ss" );
        this.fechaConvertida = fechaEmision.format ( formateador );
        this.cliente = new Cliente ( nombreCliente, dniCliente, tipoCliente );
    }
    //getters
    public int getPrecioEmitido() {
        return precioEmitido;
    }
    public static LocalDateTime getFechaEmision() {
        return fechaEmision;
    }
    public static DateTimeFormatter getFormateador() {
        return formateador;
    }
    public String getFechaConvertida() {
        return fechaConvertida;
    }
}
